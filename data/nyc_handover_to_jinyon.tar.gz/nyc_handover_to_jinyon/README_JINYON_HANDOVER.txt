PROJECT:
IST3134 NYC Yellow Taxi

SOURCE:
24 monthly Yellow Taxi files, Jan 2024–Dec 2025

RAW ROWS:
89,892,322

CLEAN STRUCTURALLY VALID ROWS:
89,291,810

STRUCTURALLY REMOVED:
600,512

IMPORTANT:
Non-positive distance/fare records were retained when structurally valid and flagged using valid_distance and valid_fare.

LOOKUP:
Pickup left join using PULocationID → LocationID

PURPOSE OF THIS FOLDER:
Small Spark outputs for pandas comparison, validation, visualisation and final report integration by Ooi Jin Yon.

IMPORTANT:
Do not treat individual preprocessing issue counts as mutually exclusive.

VALIDATION:
- Spark DataFrame and SQL validation passed.
- Monthly, distance-band, and passenger-group totals match the clean row count.
- Benchmark timings are observed timings from the two-node Learner Lab cluster.
- Timings should not be interpreted as universal performance claims.

